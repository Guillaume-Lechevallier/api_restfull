// ./src/index.js
// importing the dependencies
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const mysql = require('mysql');
const app = express();


//page d'acceuil de l'API
app.get('/', (req, res) => {
    res.send("<h1 style='font-size : 30px; font-family: Roboto,serif'>Vous êtes sur l'API Contact !</h1>");
});


//route Showuser de l'API qui affichera les enregistrements
app.get("/showcontacts/:showuser", (req, res) => {
    const db = mysql.createConnection({
        host     : 'localhost',
        user     : 'root',
        password : '',
        database : 'contact_api'
    });

    db.connect();
    app.use(helmet());
    app.use(bodyParser.json());
    app.use(cors());
    app.use(morgan('combined'));
    let showuser = req.params.showuser;
    let url = 'https://www.nothing.com?'+showuser;
    let params = (new URL(url)).searchParams;
    let numero = params.get('numero');
    let nom = params.get('nom');
    let adresse = params.get('adresse');
    let email = params.get('email');
    let website = params.get('website');
    let apartenance_utilisateur = params.get('apartenance_utilisateur');
    let tag = ['numero' ,'nom' ,'adresse' ,'email' ,'website' ,'apartenance_utilisateur'];
    let objet = [numero ,nom ,adresse ,email ,website ,apartenance_utilisateur];
    console.log(tag);
    console.log(objet)
    let commande_sql = `SELECT * from agenda where ((numero LIKE '%${numero}%') OR (nom LIKE '%${nom}%') OR (adresse LIKE '%${adresse}%') OR (email LIKE '%${email}%') OR (website LIKE '%${website}%')) OR (apartenance_utilisateur LIKE '%${apartenance_utilisateur}%')`
    console.log(commande_sql)
    db.query(commande_sql, function (err, result) {
        if (err){
            res.send(400)
        }else{res.send(result)}
        console.log(result);
        });
    });

app.post("/adduser/", (req, res) => {
    const db = mysql.createConnection({
        host     : 'localhost',
        user     : 'root',
        password : '',
        database : 'contact_api'
    });

    db.connect();
    app.use(helmet());
    app.use(bodyParser.json());
    app.use(cors());
    app.use(morgan('combined'));
    let adduser = req.params.adduser;
    let url = 'https://www.nothing.com?'+adduser;
    let params = (new URL(url)).searchParams;
    let numero = params.get('numero');
    let nom = params.get('nom');
    let adresse = params.get('adresse');
    let email = params.get('email');
    let website = params.get('website');
    let apartenance_utilisateur = params.get('apartenance_utilisateur');
    let tag = ['numero' ,'nom' ,'adresse' ,'email' ,'website' ,'apartenance_utilisateur'];
    let objet = [numero ,nom ,adresse ,email ,website ,apartenance_utilisateur];
    console.log(tag);
    console.log(objet)
    let commande_sql = `SELECT * from agenda where ((numero LIKE '%${numero}%') OR (nom LIKE '%${nom}%') OR (adresse LIKE '%${adresse}%') OR (email LIKE '%${email}%') OR (website LIKE '%${website}%')) OR (apartenance_utilisateur LIKE '%${apartenance_utilisateur}%')`
    console.log(commande_sql)
    db.query(commande_sql, function (err, result) {
        if (err){
            res.send(400)
        }else{res.send(result)}
        console.log(result);
    });
});


//démarrage du serveur
app.listen(3001, () => {
    console.log('Serveur ouvert');
});
